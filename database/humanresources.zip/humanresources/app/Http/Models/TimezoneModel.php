<?php namespace App\Http\Models;

use DB;
use Hash;
use Auth;
use Validator;

class TimezoneModel
{
    protected $table = 'm_timezones';

    public function Rules()
    {
        return array(
            'mtz_name' => 'required',           
        );
    }

    public function Messages()
    {
        return array(
            'mtz_name.required'  => trans('validation.error_mtz_name_required'),            
        );
    }

    public function get_all()
    {
        $results = DB::table($this->table)->get();//->where('last_kind', '<>', DELETE)
        return $results;
    }
   

    public function insert($data)
    {
        $results = DB::table($this->table)->insert($data);
        return $results;
    }

    public function get_by_id($id)
    {
        $results = DB::table($this->table)->where('mc_id', $id)->first();
        return $results;
    }

    
    public function update($id, $data)
    {
        $results = DB::table($this->table)->where('mc_id', $id)->update($data);          
        return $results;
    }
    /*  Delete division and section*/
    public function delete($id, $data)
    {
        $results = DB::table($this->table)->where('mc_id', $id)->orWhere('mc_parent', '=', $id)->update($data); 
        return $results;
    }
}