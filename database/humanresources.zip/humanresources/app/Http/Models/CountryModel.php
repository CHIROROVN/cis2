<?php namespace App\Http\Models;

use DB;
use Hash;
use Auth;
use Validator;

class CountryModel
{
    protected $table = 'm_country';

    public function Rules()
    {
        return array(
            'mtz_name' => 'required',           
        );
    }

    public function Messages()
    {
        return array(
            'mtz_name.required'  => trans('validation.error_mtz_name_required'),            
        );
    }

    public function get_all()
    {
        $results = DB::table($this->table)->get();//->where('last_kind', '<>', DELETE)
        return $results;
    }
   

   
}