<?php namespace App\Http\Models;

use DB;
use Hash;
use Auth;
use Validator;

class JobstitleModel
{
    protected $table = 'm_jobstitles';

    public function Rules()
    {
        return array(
            'mj_title_code' => 'required',  
            'mj_title_name' => 'required',           
        );
    }

    public function Messages()
    {
        return array(
            'mj_title_code.required'  => trans('validation.error_mj_title_code_required'), 
            'mj_title_name.required'  => trans('validation.error_mj_title_name_required'),            
        );
    }

    public function get_all()
    {
        $results = DB::table($this->table)->where('last_kind', '<>', DELETE)->get();
        return $results;
    }
   

    public function insert($data)
    {
        $results = DB::table($this->table)->insert($data);
        return $results;
    }

    public function get_by_id($id)
    {
        $results = DB::table($this->table)->where('mj_title_id', $id)->first();
        return $results;
    }

    
    public function update($id, $data)
    {
        $results = DB::table($this->table)->where('mj_title_id', $id)->update($data);          
        return $results;
    }
    /*  Delete division and section*/
    public function delete($id, $data)
    {
        $results = DB::table($this->table)->where('mj_title_id', $id)->update($data); 
        return $results;
    }
}